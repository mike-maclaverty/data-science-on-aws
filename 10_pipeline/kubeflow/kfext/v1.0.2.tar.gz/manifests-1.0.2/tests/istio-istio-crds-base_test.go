package tests_test

import (
	"sigs.k8s.io/kustomize/v3/k8sdeps/kunstruct"
	"sigs.k8s.io/kustomize/v3/k8sdeps/transformer"
	"sigs.k8s.io/kustomize/v3/pkg/fs"
	"sigs.k8s.io/kustomize/v3/pkg/loader"
	"sigs.k8s.io/kustomize/v3/pkg/plugins"
	"sigs.k8s.io/kustomize/v3/pkg/resmap"
	"sigs.k8s.io/kustomize/v3/pkg/resource"
	"sigs.k8s.io/kustomize/v3/pkg/target"
	"sigs.k8s.io/kustomize/v3/pkg/validators"
	"testing"
)

func writeIstioCrdsBase(th *KustTestHarness) {
	th.writeF("/manifests/istio/istio-crds/base/crds.yaml", `
---
apiVersion: apiextensions.k8s.io/v1beta1
kind: CustomResourceDefinition
metadata:
  name: virtualservices.networking.istio.io
  labels:
    app: istio-pilot
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: networking.istio.io
  names:
    kind: VirtualService
    listKind: VirtualServiceList
    plural: virtualservices
    singular: virtualservice
    shortNames:
    - vs
    categories:
    - istio-io
    - networking-istio-io
  scope: Namespaced
  version: v1alpha3
  additionalPrinterColumns:
  - JSONPath: .spec.gateways
    description: The names of gateways and sidecars that should apply these routes
    name: Gateways
    type: string
  - JSONPath: .spec.hosts
    description: The destination hosts to which traffic is being sent
    name: Hosts
    type: string
  - JSONPath: .metadata.creationTimestamp
    description: |-
      CreationTimestamp is a timestamp representing the server time when this object was created. It is not guaranteed to be set in happens-before order across separate operations. Clients may not set this value. It is represented in RFC3339 form and is in UTC.

      Populated by the system. Read-only. Null for lists. More info: https://git.k8s.io/community/contributors/devel/api-conventions.md#metadata
    name: Age
    type: date
---
apiVersion: apiextensions.k8s.io/v1beta1
kind: CustomResourceDefinition
metadata:
  name: destinationrules.networking.istio.io
  labels:
    app: istio-pilot
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: networking.istio.io
  names:
    kind: DestinationRule
    listKind: DestinationRuleList
    plural: destinationrules
    singular: destinationrule
    shortNames:
    - dr
    categories:
    - istio-io
    - networking-istio-io
  scope: Namespaced
  version: v1alpha3
  additionalPrinterColumns:
  - JSONPath: .spec.host
    description: The name of a service from the service registry
    name: Host
    type: string
  - JSONPath: .metadata.creationTimestamp
    description: |-
      CreationTimestamp is a timestamp representing the server time when this object was created. It is not guaranteed to be set in happens-before order across separate operations. Clients may not set this value. It is represented in RFC3339 form and is in UTC.

      Populated by the system. Read-only. Null for lists. More info: https://git.k8s.io/community/contributors/devel/api-conventions.md#metadata
    name: Age
    type: date
---
apiVersion: apiextensions.k8s.io/v1beta1
kind: CustomResourceDefinition
metadata:
  name: serviceentries.networking.istio.io
  labels:
    app: istio-pilot
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: networking.istio.io
  names:
    kind: ServiceEntry
    listKind: ServiceEntryList
    plural: serviceentries
    singular: serviceentry
    shortNames:
    - se
    categories:
    - istio-io
    - networking-istio-io
  scope: Namespaced
  version: v1alpha3
  additionalPrinterColumns:
  - JSONPath: .spec.hosts
    description: The hosts associated with the ServiceEntry
    name: Hosts
    type: string
  - JSONPath: .spec.location
    description: Whether the service is external to the mesh or part of the mesh (MESH_EXTERNAL or MESH_INTERNAL)
    name: Location
    type: string
  - JSONPath: .spec.resolution
    description: Service discovery mode for the hosts (NONE, STATIC, or DNS)
    name: Resolution
    type: string
  - JSONPath: .metadata.creationTimestamp
    description: |-
      CreationTimestamp is a timestamp representing the server time when this object was created. It is not guaranteed to be set in happens-before order across separate operations. Clients may not set this value. It is represented in RFC3339 form and is in UTC.

      Populated by the system. Read-only. Null for lists. More info: https://git.k8s.io/community/contributors/devel/api-conventions.md#metadata
    name: Age
    type: date
---
apiVersion: apiextensions.k8s.io/v1beta1
kind: CustomResourceDefinition
metadata:
  name: gateways.networking.istio.io
  labels:
    app: istio-pilot
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: networking.istio.io
  names:
    kind: Gateway
    plural: gateways
    singular: gateway
    shortNames:
    - gw
    categories:
    - istio-io
    - networking-istio-io
  scope: Namespaced
  version: v1alpha3
---
apiVersion: apiextensions.k8s.io/v1beta1
kind: CustomResourceDefinition
metadata:
  name: envoyfilters.networking.istio.io
  labels:
    app: istio-pilot
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: networking.istio.io
  names:
    kind: EnvoyFilter
    plural: envoyfilters
    singular: envoyfilter
    categories:
    - istio-io
    - networking-istio-io
  scope: Namespaced
  version: v1alpha3
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: clusterrbacconfigs.rbac.istio.io
  labels:
    app: istio-pilot
    istio: rbac
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: rbac.istio.io
  names:
    kind: ClusterRbacConfig
    plural: clusterrbacconfigs
    singular: clusterrbacconfig
    categories:
    - istio-io
    - rbac-istio-io
  scope: Cluster
  version: v1alpha1
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: policies.authentication.istio.io
  labels:
    app: istio-citadel
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: authentication.istio.io
  names:
    kind: Policy
    plural: policies
    singular: policy
    categories:
    - istio-io
    - authentication-istio-io
  scope: Namespaced
  version: v1alpha1
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: meshpolicies.authentication.istio.io
  labels:
    app: istio-citadel
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: authentication.istio.io
  names:
    kind: MeshPolicy
    listKind: MeshPolicyList
    plural: meshpolicies
    singular: meshpolicy
    categories:
    - istio-io
    - authentication-istio-io
  scope: Cluster
  version: v1alpha1
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: httpapispecbindings.config.istio.io
  labels:
    app: istio-mixer
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: HTTPAPISpecBinding
    plural: httpapispecbindings
    singular: httpapispecbinding
    categories:
    - istio-io
    - apim-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: httpapispecs.config.istio.io
  labels:
    app: istio-mixer
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: HTTPAPISpec
    plural: httpapispecs
    singular: httpapispec
    categories:
    - istio-io
    - apim-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: quotaspecbindings.config.istio.io
  labels:
    app: istio-mixer
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: QuotaSpecBinding
    plural: quotaspecbindings
    singular: quotaspecbinding
    categories:
    - istio-io
    - apim-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: quotaspecs.config.istio.io
  labels:
    app: istio-mixer
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: QuotaSpec
    plural: quotaspecs
    singular: quotaspec
    categories:
    - istio-io
    - apim-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: rules.config.istio.io
  labels:
    app: mixer
    package: istio.io.mixer
    istio: core
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: rule
    plural: rules
    singular: rule
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: attributemanifests.config.istio.io
  labels:
    app: mixer
    package: istio.io.mixer
    istio: core
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: attributemanifest
    plural: attributemanifests
    singular: attributemanifest
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: bypasses.config.istio.io
  labels:
    app: mixer
    package: bypass
    istio: mixer-adapter
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: bypass
    plural: bypasses
    singular: bypass
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: circonuses.config.istio.io
  labels:
    app: mixer
    package: circonus
    istio: mixer-adapter
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: circonus
    plural: circonuses
    singular: circonus
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: deniers.config.istio.io
  labels:
    app: mixer
    package: denier
    istio: mixer-adapter
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: denier
    plural: deniers
    singular: denier
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: fluentds.config.istio.io
  labels:
    app: mixer
    package: fluentd
    istio: mixer-adapter
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: fluentd
    plural: fluentds
    singular: fluentd
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: kubernetesenvs.config.istio.io
  labels:
    app: mixer
    package: kubernetesenv
    istio: mixer-adapter
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: kubernetesenv
    plural: kubernetesenvs
    singular: kubernetesenv
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: listcheckers.config.istio.io
  labels:
    app: mixer
    package: listchecker
    istio: mixer-adapter
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: listchecker
    plural: listcheckers
    singular: listchecker
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: memquotas.config.istio.io
  labels:
    app: mixer
    package: memquota
    istio: mixer-adapter
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: memquota
    plural: memquotas
    singular: memquota
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: noops.config.istio.io
  labels:
    app: mixer
    package: noop
    istio: mixer-adapter
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: noop
    plural: noops
    singular: noop
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: opas.config.istio.io
  labels:
    app: mixer
    package: opa
    istio: mixer-adapter
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: opa
    plural: opas
    singular: opa
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: prometheuses.config.istio.io
  labels:
    app: mixer
    package: prometheus
    istio: mixer-adapter
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: prometheus
    plural: prometheuses
    singular: prometheus
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: rbacs.config.istio.io
  labels:
    app: mixer
    package: rbac
    istio: mixer-adapter
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: rbac
    plural: rbacs
    singular: rbac
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: redisquotas.config.istio.io
  labels:
    app: mixer
    package: redisquota
    istio: mixer-adapter
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: redisquota
    plural: redisquotas
    singular: redisquota
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: signalfxs.config.istio.io
  labels:
    app: mixer
    package: signalfx
    istio: mixer-adapter
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: signalfx
    plural: signalfxs
    singular: signalfx
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: solarwindses.config.istio.io
  labels:
    app: mixer
    package: solarwinds
    istio: mixer-adapter
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: solarwinds
    plural: solarwindses
    singular: solarwinds
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: stackdrivers.config.istio.io
  labels:
    app: mixer
    package: stackdriver
    istio: mixer-adapter
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: stackdriver
    plural: stackdrivers
    singular: stackdriver
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: statsds.config.istio.io
  labels:
    app: mixer
    package: statsd
    istio: mixer-adapter
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: statsd
    plural: statsds
    singular: statsd
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: stdios.config.istio.io
  labels:
    app: mixer
    package: stdio
    istio: mixer-adapter
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: stdio
    plural: stdios
    singular: stdio
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: apikeys.config.istio.io
  labels:
    app: mixer
    package: apikey
    istio: mixer-instance
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: apikey
    plural: apikeys
    singular: apikey
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: authorizations.config.istio.io
  labels:
    app: mixer
    package: authorization
    istio: mixer-instance
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: authorization
    plural: authorizations
    singular: authorization
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: checknothings.config.istio.io
  labels:
    app: mixer
    package: checknothing
    istio: mixer-instance
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: checknothing
    plural: checknothings
    singular: checknothing
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: kuberneteses.config.istio.io
  labels:
    app: mixer
    package: adapter.template.kubernetes
    istio: mixer-instance
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: kubernetes
    plural: kuberneteses
    singular: kubernetes
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: listentries.config.istio.io
  labels:
    app: mixer
    package: listentry
    istio: mixer-instance
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: listentry
    plural: listentries
    singular: listentry
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: logentries.config.istio.io
  labels:
    app: mixer
    package: logentry
    istio: mixer-instance
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: logentry
    plural: logentries
    singular: logentry
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
  additionalPrinterColumns:
  - JSONPath: .spec.severity
    description: The importance of the log entry
    name: Severity
    type: string
  - JSONPath: .spec.timestamp
    description: The time value for the log entry
    name: Timestamp
    type: string
  - JSONPath: .spec.monitored_resource_type
    description: Optional expression to compute the type of the monitored resource this log entry is being recorded on
    name: Res Type
    type: string
  - JSONPath: .metadata.creationTimestamp
    description: |-
      CreationTimestamp is a timestamp representing the server time when this object was created. It is not guaranteed to be set in happens-before order across separate operations. Clients may not set this value. It is represented in RFC3339 form and is in UTC.

      Populated by the system. Read-only. Null for lists. More info: https://git.k8s.io/community/contributors/devel/api-conventions.md#metadata
    name: Age
    type: date
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: edges.config.istio.io
  labels:
    app: mixer
    package: edge
    istio: mixer-instance
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: edge
    plural: edges
    singular: edge
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: metrics.config.istio.io
  labels:
    app: mixer
    package: metric
    istio: mixer-instance
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: metric
    plural: metrics
    singular: metric
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: quotas.config.istio.io
  labels:
    app: mixer
    package: quota
    istio: mixer-instance
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: quota
    plural: quotas
    singular: quota
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: reportnothings.config.istio.io
  labels:
    app: mixer
    package: reportnothing
    istio: mixer-instance
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: reportnothing
    plural: reportnothings
    singular: reportnothing
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: tracespans.config.istio.io
  labels:
    app: mixer
    package: tracespan
    istio: mixer-instance
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: tracespan
    plural: tracespans
    singular: tracespan
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: rbacconfigs.rbac.istio.io
  labels:
    app: mixer
    package: istio.io.mixer
    istio: rbac
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: rbac.istio.io
  names:
    kind: RbacConfig
    plural: rbacconfigs
    singular: rbacconfig
    categories:
    - istio-io
    - rbac-istio-io
  scope: Namespaced
  version: v1alpha1
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: serviceroles.rbac.istio.io
  labels:
    app: mixer
    package: istio.io.mixer
    istio: rbac
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: rbac.istio.io
  names:
    kind: ServiceRole
    plural: serviceroles
    singular: servicerole
    categories:
    - istio-io
    - rbac-istio-io
  scope: Namespaced
  version: v1alpha1
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: servicerolebindings.rbac.istio.io
  labels:
    app: mixer
    package: istio.io.mixer
    istio: rbac
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: rbac.istio.io
  names:
    kind: ServiceRoleBinding
    plural: servicerolebindings
    singular: servicerolebinding
    categories:
    - istio-io
    - rbac-istio-io
  scope: Namespaced
  version: v1alpha1
  additionalPrinterColumns:
  - JSONPath: .spec.roleRef.name
    description: The name of the ServiceRole object being referenced
    name: Reference
    type: string
  - JSONPath: .metadata.creationTimestamp
    description: |-
      CreationTimestamp is a timestamp representing the server time when this object was created. It is not guaranteed to be set in happens-before order across separate operations. Clients may not set this value. It is represented in RFC3339 form and is in UTC.

      Populated by the system. Read-only. Null for lists. More info: https://git.k8s.io/community/contributors/devel/api-conventions.md#metadata
    name: Age
    type: date
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: adapters.config.istio.io
  labels:
    app: mixer
    package: adapter
    istio: mixer-adapter
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: adapter
    plural: adapters
    singular: adapter
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: instances.config.istio.io
  labels:
    app: mixer
    package: instance
    istio: mixer-instance
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: instance
    plural: instances
    singular: instance
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: templates.config.istio.io
  labels:
    app: mixer
    package: template
    istio: mixer-template
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: template
    plural: templates
    singular: template
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: handlers.config.istio.io
  labels:
    app: mixer
    package: handler
    istio: mixer-handler
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: handler
    plural: handlers
    singular: handler
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: cloudwatches.config.istio.io
  labels:
    app: mixer
    package: cloudwatch
    istio: mixer-adapter
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: cloudwatch
    plural: cloudwatches
    singular: cloudwatch
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: dogstatsds.config.istio.io
  labels:
    app: mixer
    package: dogstatsd
    istio: mixer-adapter
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: dogstatsd
    plural: dogstatsds
    singular: dogstatsd
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
apiVersion: apiextensions.k8s.io/v1beta1
kind: CustomResourceDefinition
metadata:
  name: sidecars.networking.istio.io
  labels:
    app: istio-pilot
    chart: istio
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: networking.istio.io
  names:
    kind: Sidecar
    plural: sidecars
    singular: sidecar
    categories:
    - istio-io
    - networking-istio-io
  scope: Namespaced
  version: v1alpha3
---
kind: CustomResourceDefinition
apiVersion: apiextensions.k8s.io/v1beta1
metadata:
  name: zipkins.config.istio.io
  labels:
    app: mixer
    package: zipkin
    istio: mixer-adapter
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: config.istio.io
  names:
    kind: zipkin
    plural: zipkins
    singular: zipkin
    categories:
    - istio-io
    - policy-istio-io
  scope: Namespaced
  version: v1alpha2
---
apiVersion: apiextensions.k8s.io/v1beta1
kind: CustomResourceDefinition
metadata:
  name: clusterissuers.certmanager.k8s.io
  labels:
    app: certmanager
    chart: certmanager
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: certmanager.k8s.io
  version: v1alpha1
  names:
    kind: ClusterIssuer
    plural: clusterissuers
  scope: Cluster
---
apiVersion: apiextensions.k8s.io/v1beta1
kind: CustomResourceDefinition
metadata:
  name: issuers.certmanager.k8s.io
  labels:
    app: certmanager
    chart: certmanager
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  group: certmanager.k8s.io
  version: v1alpha1
  names:
    kind: Issuer
    plural: issuers
  scope: Namespaced
---
apiVersion: apiextensions.k8s.io/v1beta1
kind: CustomResourceDefinition
metadata:
  name: certificates.certmanager.k8s.io
  labels:
    app: certmanager
    chart: certmanager
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  additionalPrinterColumns:
    - JSONPath: .status.conditions[?(@.type=="Ready")].status
      name: Ready
      type: string
    - JSONPath: .spec.secretName
      name: Secret
      type: string
    - JSONPath: .spec.issuerRef.name
      name: Issuer
      type: string
      priority: 1
    - JSONPath: .status.conditions[?(@.type=="Ready")].message
      name: Status
      type: string
      priority: 1
    - JSONPath: .metadata.creationTimestamp
      description: |-
        CreationTimestamp is a timestamp representing the server time when this object was created. It is not guaranteed to be set in happens-before order across separate operations. Clients may not set this value. It is represented in RFC3339 form and is in UTC.

        Populated by the system. Read-only. Null for lists. More info: https://git.k8s.io/community/contributors/devel/api-conventions.md#metadata
      name: Age
      type: date
  group: certmanager.k8s.io
  version: v1alpha1
  scope: Namespaced
  names:
    kind: Certificate
    plural: certificates
    shortNames:
      - cert
      - certs
---
apiVersion: apiextensions.k8s.io/v1beta1
kind: CustomResourceDefinition
metadata:
  name: orders.certmanager.k8s.io
  labels:
    app: certmanager
    chart: certmanager
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  additionalPrinterColumns:
    - JSONPath: .status.state
      name: State
      type: string
    - JSONPath: .spec.issuerRef.name
      name: Issuer
      type: string
      priority: 1
    - JSONPath: .status.reason
      name: Reason
      type: string
      priority: 1
    - JSONPath: .metadata.creationTimestamp
      description: |-
        CreationTimestamp is a timestamp representing the server time when this object was created. It is not guaranteed to be set in happens-before order across separate operations. Clients may not set this value. It is represented in RFC3339 form and is in UTC.

        Populated by the system. Read-only. Null for lists. More info: https://git.k8s.io/community/contributors/devel/api-conventions.md#metadata
      name: Age
      type: date
  group: certmanager.k8s.io
  version: v1alpha1
  names:
    kind: Order
    plural: orders
  scope: Namespaced
---
apiVersion: apiextensions.k8s.io/v1beta1
kind: CustomResourceDefinition
metadata:
  name: challenges.certmanager.k8s.io
  labels:
    app: certmanager
    chart: certmanager
    heritage: Tiller
    release: istio
  annotations:
    "helm.sh/resource-policy": keep
spec:
  additionalPrinterColumns:
    - JSONPath: .status.state
      name: State
      type: string
    - JSONPath: .spec.dnsName
      name: Domain
      type: string
    - JSONPath: .status.reason
      name: Reason
      type: string
    - JSONPath: .metadata.creationTimestamp
      description: |-
        CreationTimestamp is a timestamp representing the server time when this object was created. It is not guaranteed to be set in happens-before order across separate operations. Clients may not set this value. It is represented in RFC3339 form and is in UTC.

        Populated by the system. Read-only. Null for lists. More info: https://git.k8s.io/community/contributors/devel/api-conventions.md#metadata
      name: Age
      type: date
  group: certmanager.k8s.io
  version: v1alpha1
  names:
    kind: Challenge
    plural: challenges
  scope: Namespaced
`)
	th.writeK("/manifests/istio/istio-crds/base", `
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization
resources:
- crds.yaml
namespace: kubeflow
`)
}

func TestIstioCrdsBase(t *testing.T) {
	th := NewKustTestHarness(t, "/manifests/istio/istio-crds/base")
	writeIstioCrdsBase(th)
	m, err := th.makeKustTarget().MakeCustomizedResMap()
	if err != nil {
		t.Fatalf("Err: %v", err)
	}
	expected, err := m.AsYaml()
	if err != nil {
		t.Fatalf("Err: %v", err)
	}
	targetPath := "../istio/istio-crds/base"
	fsys := fs.MakeRealFS()
	lrc := loader.RestrictionRootOnly
	_loader, loaderErr := loader.NewLoader(lrc, validators.MakeFakeValidator(), targetPath, fsys)
	if loaderErr != nil {
		t.Fatalf("could not load kustomize loader: %v", loaderErr)
	}
	rf := resmap.NewFactory(resource.NewFactory(kunstruct.NewKunstructuredFactoryImpl()), transformer.NewFactoryImpl())
	pc := plugins.DefaultPluginConfig()
	kt, err := target.NewKustTarget(_loader, rf, transformer.NewFactoryImpl(), plugins.NewLoader(pc, rf))
	if err != nil {
		th.t.Fatalf("Unexpected construction error %v", err)
	}
	actual, err := kt.MakeCustomizedResMap()
	if err != nil {
		t.Fatalf("Err: %v", err)
	}
	th.assertActualEqualsExpected(actual, string(expected))
}
